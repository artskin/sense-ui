import '../style/root.css'

//import { SenseButton } from '../packages/sense-button/button.js';
import { SenseCard } from './sense-card.js';



window.customElements.define('s-button',SenseButton)
window.customElements.define('s-card',SenseCard)